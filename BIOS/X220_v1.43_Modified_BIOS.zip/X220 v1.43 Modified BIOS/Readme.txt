Here's the latest modified v1.43 X220 bios with the following features:

- Whitelist removal
- Unblocked AES-NI
- Unblocked advanced menu
- Unlocked memory speed
- Unblocked AES MSR 0xE2
- New vbios Intel 2119
- 16Gb 1866 + eGPU solved

Installation process:

1. Flash the original v1.43 BIOS (8duj28us.exe)
2. Reboot the computer.
3. Open a command prompt (cmd.exe) as administrator, navigate to the Modified bios folder and run Flash.bat
4. Follow the prompts in the Phoenix UEFI WinFlash application and wait for the computer to reboot when the process completes.
5. To confirm that the modified BIOS has installed correctly, press F1 at startup to enter BIOS Setup. If the menu "Advanced" shows, then the modified BIOS has installed correctly.

---
ValdikSS
